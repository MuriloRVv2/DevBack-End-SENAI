package br.com.suporteSenai.suporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
