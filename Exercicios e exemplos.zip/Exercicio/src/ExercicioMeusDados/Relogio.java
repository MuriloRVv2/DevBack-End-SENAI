package ExercicioMeusDados;

public class Relogio {

	public static void main(String[] args) throws InterruptedException {
		
		for (int min = 0; min < 60; min++) {

			for (int seg = 0; seg < 60; seg++) {
				
				System.out.println(min + " : " + seg);
				//Thread.sleep(1000);
				
			}
			
			
			
		}
		
	}
	
}
