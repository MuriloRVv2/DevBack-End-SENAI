package ExercicioMeusDados;

public class UsandoFor_1 {

	public static void main(String[] args) {
		
		for (int cont = 0; cont <= 10; cont++) {
			
			System.out.println("Volta: " + cont);
			
		}
		
	}
	
}
