package Lista_01;

import java.util.Scanner;

public class Algoritimo_39 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		double numero01;
		double numero02;
		double media;
		
		System.out.println("Entre com o primeiro número: ");
		numero01 = sc.nextDouble();
		System.out.println("Entre com o segundo número: ");
		numero02 = sc.nextDouble();
		media = (numero01 + numero02) / 2;
		System.out.println("O resultado da média é: " + media);
		
		
		
		
		
	}
	
}
