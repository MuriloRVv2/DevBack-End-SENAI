package Lista_01;

public class Algoritimo_30 {

	public static void main(String[] args) {
		
		int num1 = 28, num2 = 43;
		double total = num1 * num2;
		System.out.println(total);
		
		//////////////////////////////////////////////////
		
		int total1;
		total1 = 28 * 43;
		System.out.println(total1);
		
	}
	
}
