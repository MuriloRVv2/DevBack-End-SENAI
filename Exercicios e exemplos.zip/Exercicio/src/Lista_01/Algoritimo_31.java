package Lista_01;

public class Algoritimo_31 {

	public static void main(String[] args) {
	
		/*
		int num1 = 8;
		int num2 = 9;
		int num3 = 7;
		int media = (num1 + num2 + num3) / 3;
		 */
		
		double media;
		media = (8 + 9 + 7) / 3;
		System.out.println(media);
		
	}
	
}
