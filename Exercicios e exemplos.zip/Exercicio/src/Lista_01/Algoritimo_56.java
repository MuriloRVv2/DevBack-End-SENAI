package Lista_01;

import java.util.Scanner;

public class Algoritimo_56 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String nome;
		int idade;
		
		System.out.println("Entre com o seu nome: ");
		nome = sc.nextLine();
		
		System.out.println("Entre com a sua idade: ");
		idade = sc.nextInt();
		
		System.out.println("Nome: " + nome + 
										"\nIdade: " + idade);
		
		
		
	}
	
}
