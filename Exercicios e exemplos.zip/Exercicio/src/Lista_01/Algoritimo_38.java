package Lista_01;

import java.util.Scanner;

public class Algoritimo_38 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		double numero;
		double tercaParte;
		
		System.out.println("Entre com um número: ");
		numero = sc.nextDouble();
		tercaParte = numero / 3;
		System.out.println("A terça parte desse número é de: " + tercaParte);
		
		
		
	}
	
}
