package Lista_01;

import java.util.Scanner;

public class Algoritmo_267 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String profissao;
		
		System.out.println("Digite sua profissão: ");
		profissao = sc.nextLine();
		
		
			
				
		
	}
	
}
