package Lista_01;

public class Algoritimo_28 {

	public static void main(String[] args) {
		
		System.out.println("É PRECISO FAZER TODOS OS ALGORITIMOS PARA APRENDER! AMÉEEMMMM!!!!");
		
		
		
	}
	
}
