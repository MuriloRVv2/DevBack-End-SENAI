package Aula01;

import javax.swing.JOptionPane;

public class MinhaPrimeiraClasse {
	
	public static void main(String[] args) {
		
		System.out.print("Olá Mundo!");
		System.out.println("\nOlá Mundo!");
		JOptionPane.showMessageDialog(null, "Olá Mundo");
		
	}
	
}
