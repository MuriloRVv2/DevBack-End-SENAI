package POO_Package;

public class Pessoa {

	String nome;
	String telefone;
	String endereco;
	String email;
	
	
	
}
