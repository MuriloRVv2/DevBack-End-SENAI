package Calculadora;

import java.util.Scanner;

public class Calculadora {

	public static void main(String[] args) {
		
		Solicitacao chamar = new Solicitacao();
		
		chamar.solicitarOp();
		
	}
	
}
