package Calculadora;

public class CalculoCientifico extends Calculo{

	public double raizQuadrada() {
		return raizQuadrada();
	}

	
	
	
}
