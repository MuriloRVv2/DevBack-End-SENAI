package ZOO;

public class AnimalSelvagem extends Animal {

	private String nomeCientifico;

	public String getNomeCientifico() {
		return nomeCientifico;
	}

	public void setNomeCientifico(String nomeCientifico) {
		this.nomeCientifico = nomeCientifico;
	}
	
}
