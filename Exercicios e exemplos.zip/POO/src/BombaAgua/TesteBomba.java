package BombaAgua;

public class TesteBomba {

	public static void main(String[] args) throws InterruptedException {
		
		Bomba agua = new Bomba();
		
		agua.ligar();
		agua.desligar();
		
	}
	
}
