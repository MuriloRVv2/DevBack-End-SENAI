package GPS;

public class UsaGPS {

	public static void main(String[] args) {
		
		GPS gps2 = new GPS("Av. Brasil, 100", "portugues");
		gps2.mostrar();
		
		
	}
	
}
